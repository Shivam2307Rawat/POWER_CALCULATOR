import java.util.Scanner;

class MyCalculator {
    public int power(int n, int p) throws Exception {
        if (n < 0 || p < 0) {
            throw new Exception("n or p should not be negative.");
        }
        if (n == 0 && p == 0) {
            throw new Exception("n and p should not be zero.");
        }
        return (int) Math.pow(n, p);
    }
}

public class My_calculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MyCalculator myCalculator = new MyCalculator();
        boolean continueInput = true;

        while (continueInput) {
            try {
                System.out.print("Enter value of n: ");
                int n = scanner.nextInt();
                System.out.print("Enter value of p: ");
                int p = scanner.nextInt();

                int result = myCalculator.power(n, p);
                System.out.println("Result: " + result);

            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }

            System.out.print("Do you want to calculate again? (yes/no): ");
            String answer = scanner.next();
            if (!answer.equalsIgnoreCase("yes")) {
                continueInput = false;
                System.out.println("Thank you for using Power Calculator!");
            }
        }

        scanner.close();
    }
}
